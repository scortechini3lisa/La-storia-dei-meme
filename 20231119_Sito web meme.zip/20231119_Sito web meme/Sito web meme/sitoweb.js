var meme = {
    nome:"monkey_pupet",
    descrizione:"è nato in quell'anno per quel motivo",
    categoria: "Pupazzi",
    /*immagine:"C:\Users\st10451\Desktop\html\sito meme\20231116_Sito web meme\immagini\monkey_pupet.jpg"*/
    /*immagine: "C:\Users\spong\Desktop\Sciuola\tpsit\x2820231118_Sito web meme\x2820231118_Sito web meme\immagini\monkey_pupet.jpg"*/
};

var outputElement = document.getElementById('output');

outputElement.innerHTML = 'nome: ' + meme.nome + '<br>' + 'descrizione: ' + meme.descrizione + '<br>' + 'categoria: ' + meme.categoria /* + 'immagine: ' + meme.immagine*/;
//prova per visualizzare solo la categoria
var outputCategoria = document.getElementById('outputCategoria');
outputElement.innerHTML = meme.categoria;