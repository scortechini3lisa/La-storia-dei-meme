
//creazione classe meme
class memeClasse {
    constructor(nome, descrizione, categoria, immagine) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.categoria = categoria;
        this.immagine = immagine;
    }
}
// //creazione di una lista con tutti i meme
// var memeClasseLista = [
//     new memeClasse("miles morales","questo meme è nato molto recentemente","Animazione"),
//     new memeClasse("darwin","nasce dal cartone animato Gumball","Animazione")
// ]
// var outputCategoria1 = document.getElementById('outputCategoria1');
//outputCategoria1.innerHTML = memeClasseLista;

// Percorso del file
var percorsoFile = 'listaMeme.txt';
var listaMeme;
var allMeme = [];
var linkImmagine;
var specifiche;
var appoggio;
// utilizzo di fetch per ottenere i dati dal file
fetch(percorsoFile)
    .then(response => {
        if (!response.ok) { //non funzia niente qui
            throw new Error('Errore nel recupero dei dati');
        }
        return response.text();
    })
    .then(dati => {
        console.log("1: "+dati);
        listaMeme = dati.split(';');
        console.log("2: "+listaMeme);
        for (var i = 0; i < listaMeme.length - 1; i++) {
            specifiche = listaMeme[i].split('-');
            console.log("3: "+specifiche);
            appoggio = new memeClasse(specifiche[0], specifiche[1], specifiche[2], specifiche[3]);
            console.log("4");
            console.log(appoggio.nome);
            allMeme.push(appoggio);
            linkImmagine = allMeme[i].immagine;
            document.getElementById('memeNome').innerHTML = allMeme[i].nome;
            document.getElementById('memeDescrizione').innerHTML = allMeme[i].descrizione;
            document.getElementById('memeImmagine').src = allMeme[i].immagine;
        }
        // console.log("fuori ciclo for");
        // for(var i=0;i<allMeme.length;i++){
        //     console.log(allMeme[i]);
        // }
            // var nuovoDiv = document.createElement('div').textContent = allMeme[i];
            // document.getElementById('container').appendChild(nuovoDiv);
            // console.log(dati);
            // console.log(listaMeme[i]);
            // console.log(i);
            // console.log("nome meme: " + allMeme[i].nome);

            console.log("prova");// Otteniamo il riferimento all'elemento contenitore
			var container = document.getElementById('container');
			var titolo = document.getElementById('titolo');
			// Definiamos il numero di div che vogliamo creare
			var numeroDiv = allMeme.length - 1;
			console.log(allMeme.length - 1);

			// Ciclo per creare e aggiungere i div al contenitore
			for (var i = 0; i < numeroDiv; i++) {
				// Creiamo un nuovo elemento div
				var nuovoDiv = document.createElement('div');

				// Assegniamo un testo o attributi all'elemento (opzionale)
				//nuovoDiv.textContent = allMeme[i]; //testo del div
				//console.log("nuovo div: "+nuovoDiv);

				//creazione dell'oggetto titolo
				var nuovoTitolo = document.createElement('h1');
				nuovoTitolo.textContent = allMeme[i].nome;
                console.log("text content del titolo");
				console.log(nuovoTitolo.textContent);
				nuovoDiv.appendChild(nuovoTitolo);

				//creazione dell'oggetto paragrafo
				var nuovoParagrafo = document.createElement('p');
				nuovoParagrafo.textContent = allMeme[i].descrizione;
				nuovoDiv.appendChild(nuovoParagrafo);

                //crazione dell'oggetto immagine
                var nuovaImmagine = document.createElement('img');
                nuovaImmagine.src = allMeme[i].immagine;
                nuovaImmagine.width = "300";
                nuovaImmagine.height="300";
                nuovoDiv.appendChild(nuovaImmagine);

				// Aggiungiamo l'elemento div al contenitore
				container.appendChild(nuovoDiv);
                console.log("Nuovo div: ");
				console.log(nuovoDiv.textContent);
                
                nuovoDiv.classList.add('paragrafo');
			}
           
        document.addEventListener('DOMContentLoaded', function () {
            console.log("DOM caricato");
            
            //document.getElementById('memeNome').innerHTML = allMeme[0].nome;
            //document.getElementById('memeDescrizione').innerHTML = allMeme[0].descrizione;
            //document.getElementById('memeImmagine').src = allMeme[0].immagine;
        }
		);
    })
    .catch(error => {
        console.error('Errore durante il recupero dei dati:', error);
    });
    