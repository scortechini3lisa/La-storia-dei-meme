//creazione classe meme
class memeClasse {
    constructor(nome, descrizione, categoria, immagine) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.categoria = categoria;
        this.immagine = immagine;
    }
}

// Percorso del file
var percorsoFile = 'listaMeme.txt';
// Variabili per il salvataggio dei meme
var listaMeme;
var allMeme = [];
//var linkImmagine;
var specifiche;
var appoggio;
// Utilizzo di fetch per ottenere i dati dal file
fetch(percorsoFile)
    .then(response => {
        if (!response.ok) {
            throw new Error('Errore nel recupero dei dati');
        }
        return response.text();
    })
    .then(dati => {
        // Caricamento dei dati
        listaMeme = dati.split(';');
        for (var i = 0; i < listaMeme.length; i++) {
            // Salvataggio dei singoli meme
            specifiche = listaMeme[i].split('-');
            // Salvataggio delle specifiche di ogni meme
            appoggio = new memeClasse(specifiche[0], specifiche[1], specifiche[2], specifiche[3]);
            // Inserimento del meme nella lista di tutti i meme
            allMeme.push(appoggio);
            //linkImmagine = allMeme[i].immagine;
            // document.getElementById('memeNome').innerHTML = allMeme[i].nome;
            // document.getElementById('memeDescrizione').innerHTML = allMeme[i].descrizione;
            // document.getElementById('memeImmagine').src = allMeme[i].immagine;
        }
            // Otteniamo il riferimento all'elemento contenitore
			var container = document.getElementById('container');
			// Definiamos il numero di div che vogliamo creare
			var numeroDiv = allMeme.length - 1;

			// Ciclo per creare e aggiungere i div al contenitore
			for (var i = 0; i < numeroDiv; i++) {
				// Creiamo un nuovo elemento div
				var nuovoDiv = document.createElement('div');

				// Creazione dell'oggetto titolo
				var nuovoTitolo = document.createElement('h1');
				nuovoTitolo.textContent = allMeme[i].nome;
				nuovoDiv.appendChild(nuovoTitolo);

				// Creazione dell'oggetto paragrafo
				var nuovoParagrafo = document.createElement('p');
				nuovoParagrafo.textContent = allMeme[i].descrizione;
				nuovoDiv.appendChild(nuovoParagrafo);

                var nuovoDivImmagini = document.createElement('div');
                nuovoDiv.appendChild(nuovoDivImmagini);
                
                // Crazione degli oggetto immagine
                var nuovaImmagine = document.createElement('img');
                nuovaImmagine.src = allMeme[i].immagine;
                nuovaImmagine.width = "100";
                nuovaImmagine.height="100";
                nuovoDiv.appendChild(nuovaImmagine);
                
                var nuovaImmagine2 = document.createElement('img');
                nuovaImmagine2.src = allMeme[i].immagine;
                nuovaImmagine2.width = "100";
                nuovaImmagine2.height="100";
                nuovoDiv.appendChild(nuovaImmagine2);

                
                var nuovaImmagine3 = document.createElement('img');
                nuovaImmagine3.src = allMeme[i].immagine;
                nuovaImmagine3.width = "100";
                nuovaImmagine3.height="100";
                nuovoDiv.appendChild(nuovaImmagine3);

				// Aggiungiamo l'elemento div al contenitore
				container.appendChild(nuovoDiv);
                
                nuovaImmagine.classList.add('immagine');
                nuovaImmagine2.classList.add('immagine');
                nuovaImmagine3.classList.add('immagine');
                nuovoDivImmagini.classList.add('contenitoreImmagini');
                nuovoDiv.classList.add('paragrafo');
			}
           
        document.addEventListener('DOMContentLoaded', function () {
            console.log("DOM caricato");
        }
		);
    })
    .catch(error => {
        console.error('Errore durante il recupero dei dati:', error);
    });
    