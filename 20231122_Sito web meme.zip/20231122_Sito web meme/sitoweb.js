// var meme = {
//     nome:"monkey_pupet",
//     descrizione:"è nato in quell'anno per quel motivo",
//     categoria: "Pupazzi",
//     /*immagine:"C:\Users\st10451\Desktop\html\sito meme\20231116_Sito web meme\immagini\monkey_pupet.jpg"*/
//     /*immagine: "C:\Users\spong\Desktop\Sciuola\tpsit\x2820231118_Sito web meme\x2820231118_Sito web meme\immagini\monkey_pupet.jpg"*/
// };

// var outputElement = document.getElementById('output');

// //outputElement.innerHTML = 'nome: ' + meme.nome + '<br>' + 'descrizione: ' + meme.descrizione + '<br>' + 'categoria: ' + meme.categoria /* + 'immagine: ' + meme.immagine*/;
// //prova per visualizzare solo la categoria
// var outputCategoria = document.getElementById('outputCategoria');
// //outputCategoria.innerHTML = meme.categoria;


//creazione classe meme
class memeClasse {
    constructor(nome, descrizione, categoria, immagine) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.categoria = categoria;
        this.immagine = immagine;
    }
}

// //creazione di una lista con tutti i meme
// var memeClasseLista = [
//     new memeClasse("miles morales","questo meme è nato molto recentemente","Animazione"),
//     new memeClasse("darwin","nasce dal cartone animato Gumball","Animazione")
// ]

// var outputCategoria1 = document.getElementById('outputCategoria1');
//outputCategoria1.innerHTML = memeClasseLista;

// Percorso del file
var percorsoFile = 'listaMeme.txt';
var listaMeme;
var allMeme = [];
var linkImmagine;
var ne;
// utilizzo di fetch per ottenere i dati dal file
fetch(percorsoFile)
    .then(response => {
        if (!response.ok) { //non funzia niente qui
            throw new Error('Errore nel recupero dei dati');
        }
        return response.text();
    })
    .then(dati => {
        //var scritte = dati;
        listaMeme = dati.split(';');
        ne = listaMeme.length - 1;
        for (var i = 0; i < listaMeme.length - 1; i++) {
            var specifiche = listaMeme[i].split('-');
            var appoggio = new memeClasse(specifiche[0], specifiche[1], specifiche[2], specifiche[3]);
            allMeme.push(appoggio);
            console.log(allMeme[i].immagine);
            linkImmagine = allMeme[i].immagine;
            document.getElementById('memeNome').innerHTML = allMeme[i].nome;
            document.getElementById('memeDescrizione').innerHTML = allMeme[i].descrizione;
            document.getElementById('memeImmagine').src = allMeme[i].immagine;
            // var nuovoDiv = document.createElement('div').textContent = allMeme[i];
            // document.getElementById('container').appendChild(nuovoDiv);
            // console.log(dati);
            // console.log(listaMeme[i]);
            // console.log(i);
            // console.log("nome meme: " + allMeme[i].nome);
        }

        var nuovoDiv;
        document.addEventListener('DOMContentLoaded', function () {
            // Otteniamo il riferimento all'elemento contenitore
            var contenitore = document.getElementById('contenitore');
            var titolo = document.getElementById('titolo');
            // Definiamos il numero di div che vogliamo creare
            var numeroDiv = ne;
            console.log(ne);

            // Ciclo per creare e aggiungere i div al contenitore
            for (var i = 1; i <= numeroDiv; i++) {
                // Creiamo un nuovo elemento div
                nuovoDiv = document.createElement('div');

                // Assegniamo un testo o attributi all'elemento (opzionale)
                nuovoDiv.textContent = "div " + i;

                // Aggiungiamo l'elemento div al contenitore
                contenitore.appendChild(nuovoDiv);
            }
        });
    })
    .catch(error => {
        console.error('Errore durante il recupero dei dati:', error);
    });