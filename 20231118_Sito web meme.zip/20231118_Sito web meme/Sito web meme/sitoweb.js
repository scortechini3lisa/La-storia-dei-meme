var meme = {
    nome:"monkey_pupet",
    descrizione:"è nato in quell'anno per quel motivo",
    categoria: "Pupazzi",
    immagine:"C:\Users\st10451\Desktop\html\sito meme\20231116_Sito web meme\immagini\monkey_pupet.jpg"
};

var outputElement = document.getElementById("output");

outputElement.innerHTML = 'nome: ' + meme.nome + '<br>' + 'descrizione: ' + meme.descrizione + '<br>' + 'categoria: ' + meme.categoria + 'immagine: ' + meme.immagine;