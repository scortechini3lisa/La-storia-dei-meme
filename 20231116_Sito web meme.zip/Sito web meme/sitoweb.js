// Accedi alla variabile CSS
/*const root = document.documentElement;
var larghezzaFinestra =  getComputedStyle(root).getPropertyValue('--larghezzaFinestra');*/
var elemento = document.getElementById('mieVariabili');
var _larghezzaFinestra = getComputedStyle(elemento).getPropertyValue('--larghezzaFinestra');

console.log(larghezzaFinestra);
larghezzaFinestra = parseInt(larghezzaFinestra, 10);
console.log(larghezzaFinestra);
console.log("Dimensione finestra: ",larghezzaFinestra);
larghezzaFinestra = larghezzaFinestra+2;
console.log("Dimensione dimezzata: ",larghezzaFinestra);